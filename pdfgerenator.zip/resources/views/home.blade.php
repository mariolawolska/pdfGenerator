<!DOCTYPE html>

<html>
    @include('leyout.head')

    <body>
        <div class="container">
            <a class="btn btn-primary" href="{{ route('persons') }}" role="button">Add Comments 1</a>
        </div>


    </body>

</html>