<div style=" background: #fff; padding: 15px; padding-bottom:30px">
    TOTAL NUMBER OF COMMENTS:  <span style="font-size: 26px; margin-right: 10px;">{{ $personQty }}<span>
</div>
