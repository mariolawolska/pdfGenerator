<div class="btn btn-primary form-group btn btn-lg btn-primary btn-block btn-login text-uppercase " style="border-radius: 30px;">
    <div id="addCommentForm">Submit</div>
</div>

<div id="personsError"></div>
