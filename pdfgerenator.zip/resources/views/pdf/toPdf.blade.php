<div class="row">
    <div class="col-md-12">
        <a class="btn btn-lg btn-primary btn-block btn-login text-uppercase  mb-2" href="{{ route('toPdf') }}" 
           style="border-radius: 60px; font-size: 16px"role="button">To Pdf</a>
    </div>
</div>