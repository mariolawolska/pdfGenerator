<div id="ajaxCommentTable1"></div>
<!--<div id="ajaxCommentTable2"></div>--><?php /**PATH /home/wolscy/public_html/pdfgenerator/resources/views/comment/table.blade.php ENDPATH**/ ?>