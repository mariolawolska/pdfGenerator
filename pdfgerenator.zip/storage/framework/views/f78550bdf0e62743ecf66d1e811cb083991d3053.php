<div style=" background: #fff; padding: 15px; padding-bottom:30px">
    TOTAL NUMBER OF COMMENTS:  <span style="font-size: 26px; margin-right: 10px;"><?php echo e($personQty); ?><span>
</div>
<?php /**PATH /home/wolscy/public_html/pdfgenerator/resources/views/comment/countPersons.blade.php ENDPATH**/ ?>