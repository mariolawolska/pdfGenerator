<!--<div class="pt-5 col-12 text-right">
Ignition LTD,
5 Broad Lane,
Bracknell,
tel. 4434 4343 434

</div>
<p class="text-uppercase text-center pb-5 pt-5"> activity and user comments report</p>-->
<?php /**PATH /home/wolscy/public_html/pdfgenerator/resources/views/pdf/headPdf.blade.php ENDPATH**/ ?>