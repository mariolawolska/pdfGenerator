<!DOCTYPE html>

<html>
    <?php echo $__env->make('leyout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <body style="margin-top: 10px; background-image:url('https://s3-us-west-2.amazonaws.com/s.cdpn.io/28963/form-bk.jpg'); background-size: 100%">
        <div class="container">
            <div class="row">
                <div class="col-12" style="padding-bottom: 40px">

                    <?php echo $__env->make('comment.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </div>
            </div>
            <div class="row">
                <div class="col-12">

                    <?php if(Session::has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('success')); ?>

                        <?php echo e(Session::forget('success')); ?>

                    </div>
                    <?php endif; ?>

                    <?php echo $__env->make('comment.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </div>
            </div>
        </div>

    </body>

</html><?php /**PATH /home/wolscy/public_html/pdfgenerator/resources/views/comment/persons.blade.php ENDPATH**/ ?>