<div class="row">
    <div class="col-md-12">
        <a class="btn btn-lg btn-primary btn-block btn-login text-uppercase  mb-2" href="<?php echo e(route('toPdf')); ?>" 
           style="border-radius: 60px; font-size: 16px"role="button">To Pdf</a>
    </div>
</div><?php /**PATH /home/wolscy/public_html/pdfgenerator/resources/views/pdf/toPdf.blade.php ENDPATH**/ ?>