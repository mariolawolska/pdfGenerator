<!DOCTYPE html>

<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="<?php echo e($logout?"d-none":""); ?> col-md-12">
    <a  href="<?php echo e(url('logout')); ?>">Logout</a>
    <a  href="<?php echo e(url('dashboard')); ?>">Back</a>
</div>

<div style="margin:0 60px; border: 1px solid grey">
    <div class="bg">
        <div class="pt-5 col-12 text-right">
            Ignition LTD,
            5 Broad Lane,
            Bracknell,
            tel. 4434 4343 434

        </div>
        <p class="text-uppercase text-center pb-5 pt-5"> activity and user comments report</p>

    </div>

    <div class="col-md-12">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>E-Mail</th>
                    <th>Comment</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $persons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($person->id); ?></td>
                    <td><?php echo e($person->name); ?></td>
                    <td><?php echo e($person->email); ?></td>
                    <td><?php echo e($person->comment); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>


    <div class="bg">
        <p class="text-uppercase pt-5 pb-5 mt-4 text-center"> Report date: <br>(<?php echo e(date('Y-m-d')); ?>)</p>
    </div>
    <div class="text-center">
        <?php if($flow==='view'): ?>
        <?php echo e($persons->links()); ?>

        <?php endif; ?>
    </div>
</div>
<?php /**PATH /home/wolscy/public_html/pdfgenerator/resources/views/pdf/layout.blade.php ENDPATH**/ ?>