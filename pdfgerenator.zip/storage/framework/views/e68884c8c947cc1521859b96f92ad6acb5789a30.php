<?php if($error == 'error'): ?>
<div class="text-danger" style="padding: 15px" role="alert">
    This is a danger alert—check it out! <?php echo e($error); ?>

</div>
<?php endif; ?><?php /**PATH /home/wolscy/public_html/pdfgenerator/resources/views/comment/ajaxTableError.blade.php ENDPATH**/ ?>