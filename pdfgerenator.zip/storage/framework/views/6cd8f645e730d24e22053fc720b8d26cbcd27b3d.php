<!DOCTYPE html>
<html>
    <head>
        <title>Welcome</title>

        <?php echo $__env->make('leyout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </head>
    <body style="background: #BC9B78">
        <div class="container-fluid">
            <div class="row no-gutter">
                <div class="d-none d-md-flex col-md-4 col-lg-6 bg-image"></div>
                <div class="col-md-8 col-lg-6">
                    <div class="login d-flex align-items-center py-5">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-9 col-lg-8 mx-auto">

                                    <div class="mb-4 col-md-8" style="background: #BC9B78; padding: 15px;">
                                        <h3 class="login-heading mb-4">Welcome <?php echo e(ucfirst(Auth()->user()->name)); ?> !</h3>

                                        <?php echo $__env->make('pdf.toPdf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php echo $__env->make('pdf.toTable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                        <div class="row pt-5">
                                            <div class="col-md-4">
                                                <a  href="<?php echo e(url('logout')); ?>">Logout</a>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </body>
</html><?php /**PATH /home/wolscy/public_html/pdfgenerator/resources/views/dashboard.blade.php ENDPATH**/ ?>