<!DOCTYPE html>
<html>
    <?php echo $__env->make('layout.head_login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <body>
        <div class="container-fluid bg">
            <div class="row no-gutter">
                <div class="d-none d-md-flex col-md-4 col-lg-6 bg-image"></div>
                <div class="col-md-8 col-lg-6">
                    <div class="login d-flex align-items-center py-5">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-9 col-lg-8 mx-auto">
                                    <h3 class="login-heading mb-4">Welcome</h3>
                                    <form action="<?php echo e(url('post-login')); ?>" method="POST" id="logForm">

                                        <?php echo e(csrf_field()); ?>


                                        <div class="form-label-group">
                                            <input type="email" name="email" id="inputEmail" class="form-control" placeholder="Email address" >
                                            <label for="inputEmail">Email address</label>

                                            <?php if($errors->has('email')): ?>
                                            <span class="error"><?php echo e($errors->first('email')); ?></span>
                                            <?php endif; ?>    
                                        </div> 

                                        <div class="form-label-group">
                                            <input type="password" name="password" id="inputPassword" class="form-control" placeholder="Password">
                                            <label for="inputPassword">Password</label>

                                            <?php if($errors->has('password')): ?>
                                            <span class="error"><?php echo e($errors->first('password')); ?></span>
                                            <?php endif; ?>  
                                        </div>

                                        <?php if(\Session::has('success')): ?>
                                        <div class="alert alert-success">
                                            <ul>
                                                <li><?php echo \Session::get('success'); ?></li> 		
                                            </ul>
                                        </div>
                                        <?php endif; ?>

                                        <button class="btn btn-lg btn-primary btn-block btn-login text-uppercase font-weight-bold mb-2" type="submit">Sign In</button>
                                        <div class="text-center">If you have an account?
                                            <a class="small" href="<?php echo e(url('registration')); ?>">Sign Up</a></div>
                                            
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html><?php /**PATH /home/wolscy/public_html/pdfgenerator/resources/views/login/login.blade.php ENDPATH**/ ?>