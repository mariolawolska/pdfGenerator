<div style="padding: 30px 0;  font-weight: bold;"> <h3>LIST OF LAST 5 ADDED COMMENTS</h3></div>
<table class="table">
    <thead>
        <tr>
            <th scope="col">#1</th>
            <th scope="col">NAME</th>
            <th scope="col">EMAIL</th>
            <th scope="col">COMMENT</th>
            <th scope="col">UPDATED</th>
            <th scope="col">CREATED</th>
            <th scope="col"></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $persons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($person->id); ?></td>
            <td><?php echo e($person->name); ?></td>
            <td><?php echo e($person->email); ?></td>
            <td><?php echo e($person->comment); ?></td>
            <td><?php echo e($person->updated_at); ?></td>
            <td><?php echo e($person->created_at); ?></td>
            <td><button  personId="<?php echo e($person->id); ?>" class="btn btn-danger deleteCommentForm" style="border-radius: 50%;">Delete</button></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH /home/wolscy/public_html/pdfgenerator/resources/views/comment/ajaxTable1.blade.php ENDPATH**/ ?>