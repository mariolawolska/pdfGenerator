<div class="row">
    <div class="col-md-12">
        <a class="btn btn-lg btn-primary btn-block btn-login text-uppercase  mb-2" href="<?php echo e(route('toTable')); ?>" 
           style="border-radius: 60px; font-size: 16px"role="button">To Table</a>
    </div>
</div><?php /**PATH /home/wolscy/public_html/pdfgenerator/resources/views/pdf/toTable.blade.php ENDPATH**/ ?>